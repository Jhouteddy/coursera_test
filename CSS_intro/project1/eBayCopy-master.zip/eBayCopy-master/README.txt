Do this small project to familiar with html and css
